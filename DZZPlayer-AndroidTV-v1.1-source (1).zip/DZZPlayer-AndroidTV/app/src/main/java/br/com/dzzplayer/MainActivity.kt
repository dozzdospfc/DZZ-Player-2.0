package br.com.dzzplayer

import android.app.Activity
import android.app.AlertDialog
import android.content.res.ColorStateList
import android.graphics.Color
import android.graphics.Typeface
import android.os.Bundle
import android.view.Gravity
import android.view.KeyEvent
import android.view.View
import android.view.WindowManager
import android.webkit.WebChromeClient
import android.webkit.WebSettings
import android.webkit.WebView
import android.widget.*
import androidx.annotation.OptIn
import androidx.media3.common.MediaItem
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.common.util.UnstableApi
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView
import org.json.JSONArray
import org.json.JSONObject
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL
import java.util.concurrent.Executors

data class Channel(val name: String, val url: String, val group: String = "Outros", val isEmbed: Boolean = false)

@OptIn(UnstableApi::class)
class MainActivity : Activity() {
    private val bg = Color.rgb(9, 13, 22)
    private val panel = Color.rgb(17, 25, 40)
    private val rowBg = Color.rgb(25, 36, 58)
    private val blue = Color.rgb(35, 145, 245)
    private val brightBlue = Color.rgb(90, 180, 255)
    private val focusBg = Color.rgb(52, 84, 132)
    private val white = Color.WHITE
    private val channels = mutableListOf<Channel>()
    private val favorites = mutableSetOf<String>()
    private var selectedGroup = "Todos"
    private var player: ExoPlayer? = null
    private lateinit var playerView: PlayerView
    private lateinit var webView: WebView
    private lateinit var list: LinearLayout
    private lateinit var groups: LinearLayout
    private lateinit var title: TextView
    private lateinit var count: TextView
    private val prefs by lazy { getSharedPreferences("dzz", MODE_PRIVATE) }
    private val executor = Executors.newSingleThreadExecutor()

    // Converte dp em pixels (a versão 1.0 usava pixels fixos, que ficam minúsculos em TVs 4K).
    private fun dp(v: Int): Int = (v * resources.displayMetrics.density + 0.5f).toInt()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        loadSaved()
        buildUi()
        renderGroups()
        renderChannels()
        if (channels.isEmpty()) showWelcome()
    }

    private fun buildUi() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(bg)
            setPadding(dp(26), dp(18), dp(26), dp(18))
        }
        val header = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL }
        val brand = TextView(this).apply {
            text = "DZZ  PLAYER"
            textSize = 25f; setTextColor(white); typeface = Typeface.DEFAULT_BOLD
        }
        count = TextView(this).apply {
            text = "  •  Sua TV, do seu jeito"
            textSize = 14f; setTextColor(Color.LTGRAY)
        }
        header.addView(brand); header.addView(count)
        val actions = LinearLayout(this).apply {
            gravity = Gravity.CENTER_VERTICAL
            addView(actionButton("＋  Adicionar lista") { addM3uDialog() })
            addView(actionButton("＋  Embed / link") { addLinkDialog() })
            addView(actionButton("★  Favoritos") { selectedGroup = "Favoritos"; renderGroups(); renderChannels() })
        }
        root.addView(header, LinearLayout.LayoutParams(-1, dp(54)))
        root.addView(actions, LinearLayout.LayoutParams(-1, dp(58)))
        val body = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        groups = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; setPadding(0, dp(10), dp(12), 0); setBackgroundColor(bg)
        }
        val groupScroll = ScrollView(this).apply { isFocusable = false; addView(groups) }
        body.addView(groupScroll, LinearLayout.LayoutParams(dp(190), -1))
        val channelPanel = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; setPadding(dp(12), dp(10), dp(12), dp(10)); setBackgroundColor(panel)
        }
        title = TextView(this).apply {
            text = "CANAIS"; textSize = 16f; setTextColor(white); typeface = Typeface.DEFAULT_BOLD
        }
        list = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val channelScroll = ScrollView(this).apply { addView(list) }
        channelPanel.addView(title, LinearLayout.LayoutParams(-1, dp(38)))
        channelPanel.addView(channelScroll, LinearLayout.LayoutParams(-1, 0, 1f))
        body.addView(channelPanel, LinearLayout.LayoutParams(dp(310), -1))
        val videoPanel = FrameLayout(this).apply {
            setBackgroundColor(Color.BLACK)
        }
        playerView = PlayerView(this).apply {
            useController = true
            controllerAutoShow = true
            setShowBuffering(PlayerView.SHOW_BUFFERING_WHEN_PLAYING)
        }
        webView = WebView(this).apply {
            setBackgroundColor(Color.BLACK)
            webChromeClient = WebChromeClient()
            settings.javaScriptEnabled = true
            settings.domStorageEnabled = true
            settings.mediaPlaybackRequiresUserGesture = false
            settings.mixedContentMode = WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE
            visibility = View.GONE
        }
        videoPanel.addView(playerView, FrameLayout.LayoutParams(-1, -1))
        videoPanel.addView(webView, FrameLayout.LayoutParams(-1, -1))
        body.addView(videoPanel, LinearLayout.LayoutParams(0, -1, 1f))
        root.addView(body, LinearLayout.LayoutParams(-1, 0, 1f))
        setContentView(root)
    }

    private fun actionButton(label: String, click: () -> Unit): Button =
        Button(this).apply {
            text = label; textSize = 13f; isAllCaps = false; setTextColor(white)
            setBackgroundTintList(ColorStateList.valueOf(panel))
            // Destaque visível do foco para navegação com o controle remoto.
            setOnFocusChangeListener { v, hasFocus ->
                v.setBackgroundTintList(ColorStateList.valueOf(if (hasFocus) blue else panel))
            }
            setOnClickListener { click() }
            setPadding(dp(14), dp(4), dp(14), dp(4))
        }

    private fun groupButton(name: String): TextView = TextView(this).apply {
        text = name; textSize = 15f; setTextColor(white); gravity = Gravity.CENTER_VERTICAL
        setPadding(dp(16), 0, dp(8), 0); isFocusable = true
        val isSel = selectedGroup == name
        val normal = if (isSel) blue else panel
        setBackgroundColor(normal)
        setOnFocusChangeListener { v, hasFocus ->
            v.setBackgroundColor(if (hasFocus) (if (isSel) brightBlue else focusBg) else normal)
        }
        layoutParams = LinearLayout.LayoutParams(-1, dp(48)).apply { bottomMargin = dp(5) }
        setOnClickListener { selectedGroup = name; renderGroups(true); renderChannels() }
    }

    private fun renderGroups(focusSelected: Boolean = false) {
        groups.removeAllViews()
        val names = mutableListOf("Todos", "Favoritos")
        channels.map { it.group }.distinct().sorted().forEach { if (it !in names) names.add(it) }
        names.forEach { n ->
            val btn = groupButton(n)
            groups.addView(btn)
            if (focusSelected && n == selectedGroup) btn.requestFocus()
        }
    }

    private fun renderChannels(focusStarIndex: Int = -1) {
        list.removeAllViews()
        val filtered = when (selectedGroup) {
            "Todos" -> channels
            "Favoritos" -> channels.filter { favorites.contains(it.url) }
            else -> channels.filter { it.group == selectedGroup }
        }
        title.text = "${selectedGroup.uppercase()}  •  ${filtered.size}"
        if (filtered.isEmpty()) {
            list.addView(TextView(this).apply {
                text = "Nenhum canal nesta categoria.\nAdicione uma lista M3U ou um link."
                setTextColor(Color.LTGRAY); textSize = 15f; setPadding(dp(12), dp(24), dp(12), dp(24))
            })
        }
        var starToFocus: View? = null
        filtered.forEachIndexed { index, channel ->
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
                setPadding(dp(10), 0, dp(8), 0); isFocusable = true; isClickable = true
                setBackgroundColor(rowBg)
                setOnFocusChangeListener { v, hasFocus -> v.setBackgroundColor(if (hasFocus) focusBg else rowBg) }
                layoutParams = LinearLayout.LayoutParams(-1, dp(54)).apply { bottomMargin = dp(5) }
            }
            val number = TextView(this).apply {
                text = "%02d".format(index + 1); setTextColor(blue); textSize = 14f
                typeface = Typeface.DEFAULT_BOLD
            }
            val nameView = TextView(this).apply {
                text = "  ${channel.name}"; setTextColor(white); textSize = 14f
                maxLines = 1; ellipsize = android.text.TextUtils.TruncateAt.END
            }
            val star = TextView(this).apply {
                text = if (favorites.contains(channel.url)) "★" else "☆"
                setTextColor(Color.rgb(255, 195, 65)); textSize = 20f; gravity = Gravity.CENTER
                isFocusable = true
                setBackgroundColor(Color.TRANSPARENT)
                setOnFocusChangeListener { v, hasFocus ->
                    v.setBackgroundColor(if (hasFocus) focusBg else Color.TRANSPARENT)
                }
                setOnClickListener { toggleFavorite(channel); renderChannels(index) }
            }
            if (index == focusStarIndex) starToFocus = star
            row.addView(number, LinearLayout.LayoutParams(dp(34), -1))
            row.addView(nameView, LinearLayout.LayoutParams(0, -1, 1f).apply { gravity = Gravity.CENTER_VERTICAL })
            row.addView(star, LinearLayout.LayoutParams(dp(40), -1))
            row.setOnClickListener { play(channel) }
            list.addView(row)
        }
        starToFocus?.requestFocus()
    }

    private fun play(channel: Channel) {
        if (channel.isEmbed) {
            player?.release(); player = null
            playerView.player = null
            playerView.visibility = View.GONE
            webView.visibility = View.VISIBLE
            webView.loadUrl(channel.url)
        } else {
            webView.stopLoading(); webView.visibility = View.GONE
            playerView.visibility = View.VISIBLE
            player?.release()
            player = ExoPlayer.Builder(this).build().also { p ->
                playerView.player = p
                p.addListener(object : Player.Listener {
                    override fun onPlayerError(error: PlaybackException) {
                        toast("Não foi possível reproduzir este canal (${error.errorCodeName}).")
                    }
                })
                p.setMediaItem(MediaItem.fromUri(channel.url))
                p.prepare(); p.playWhenReady = true
            }
        }
    }

    private fun addM3uDialog() {
        val input = EditText(this).apply {
            hint = "https://exemplo.com/lista.m3u"
            setTextColor(white); setHintTextColor(Color.GRAY)
            setSingleLine(true); textSize = 16f
        }
        val box = LinearLayout(this).apply { setPadding(dp(24), dp(8), dp(24), 0); addView(input) }
        AlertDialog.Builder(this).setTitle("Adicionar lista M3U / M3U8")
            .setView(box).setNegativeButton("Cancelar", null)
            .setPositiveButton("Importar") { _, _ -> importM3u(input.text.toString().trim()) }
            .show()
    }

    private fun addLinkDialog() {
        val layout = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(24), dp(8), dp(24), 0) }
        val name = EditText(this).apply { hint = "Nome do canal"; setTextColor(white); setHintTextColor(Color.GRAY) }
        val url = EditText(this).apply { hint = "URL do vídeo ou embed"; setTextColor(white); setHintTextColor(Color.GRAY) }
        val type = Spinner(this).apply {
            adapter = ArrayAdapter(this@MainActivity, android.R.layout.simple_spinner_dropdown_item,
                listOf("Link de vídeo (HLS/MP4)", "Página embed (WebView)"))
        }
        layout.addView(name); layout.addView(url); layout.addView(type)
        AlertDialog.Builder(this).setTitle("Adicionar canal").setView(layout)
            .setNegativeButton("Cancelar", null)
            .setPositiveButton("Salvar") { _, _ ->
                val n = name.text.toString().trim().ifBlank { "Novo canal" }
                val u = url.text.toString().trim()
                if (u.startsWith("https://") || u.startsWith("http://")) {
                    channels.add(Channel(n, u, "Adicionados", type.selectedItemPosition == 1))
                    saveChannels(); renderGroups(); renderChannels()
                } else toast("Informe um endereço HTTP ou HTTPS válido.")
            }.show()
    }

    // Baixa o texto da URL seguindo redirecionamentos (inclusive http -> https,
    // que o HttpURLConnection não segue sozinho).
    private fun fetchText(source: String): String {
        var current = source
        repeat(6) {
            val conn = URL(current).openConnection() as HttpURLConnection
            conn.connectTimeout = 15000; conn.readTimeout = 20000
            conn.instanceFollowRedirects = false
            conn.setRequestProperty("User-Agent", "DZZPlayer/1.1")
            val code = conn.responseCode
            if (code in 300..399) {
                val loc = conn.getHeaderField("Location")
                conn.disconnect()
                if (loc.isNullOrBlank()) throw IOException("Redirecionamento sem destino")
                current = URL(URL(current), loc).toString()
            } else if (code in 200..299) {
                val text = conn.inputStream.bufferedReader().use { it.readText() }
                conn.disconnect()
                return text
            } else {
                conn.disconnect()
                throw IOException("HTTP $code")
            }
        }
        throw IOException("Redirecionamentos demais")
    }

    private fun importM3u(source: String) {
        if (!source.startsWith("http://") && !source.startsWith("https://")) {
            toast("Informe uma URL M3U válida."); return
        }
        toast("Importando lista…")
        executor.execute {
            try {
                val text = fetchText(source)
                val parsed = parseM3u(text)
                runOnUiThread {
                    if (parsed.isEmpty()) toast("Não encontrei canais nessa lista.")
                    else {
                        channels.removeAll { it.group != "Adicionados" }
                        channels.addAll(parsed)
                        prefs.edit().putString("playlist_url", source).apply()
                        saveChannels(); renderGroups(); renderChannels()
                        toast("${parsed.size} canais importados.")
                    }
                }
            } catch (e: Exception) {
                runOnUiThread { toast("Falha ao importar. Confira a URL e a conexão.") }
            }
        }
    }

    private fun parseM3u(data: String): List<Channel> {
        val result = mutableListOf<Channel>()
        val groupRegex = Regex("""group-title=["']([^"']+)["']""", RegexOption.IGNORE_CASE)
        var name = "Canal"; var group = "Outros"
        data.lineSequence().forEach { raw ->
            val line = raw.trim()
            if (line.startsWith("#EXTINF", true)) {
                name = line.substringAfterLast(",", "Canal").trim().ifBlank { "Canal" }
                group = groupRegex.find(line)?.groupValues?.get(1) ?: "Outros"
            } else if (line.startsWith("http://") || line.startsWith("https://")) {
                result.add(Channel(name, line, group))
                name = "Canal"; group = "Outros"
            }
        }
        return result
    }

    private fun toggleFavorite(channel: Channel) {
        if (!favorites.add(channel.url)) favorites.remove(channel.url)
        prefs.edit().putString("favorites", JSONArray(favorites.toList()).toString()).apply()
    }

    private fun saveChannels() {
        val arr = JSONArray()
        channels.forEach { c -> arr.put(JSONObject().put("name", c.name).put("url", c.url).put("group", c.group).put("embed", c.isEmbed)) }
        prefs.edit().putString("channels", arr.toString()).apply()
    }

    private fun loadSaved() {
        try {
            val arr = JSONArray(prefs.getString("channels", "[]"))
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                channels.add(Channel(o.optString("name"), o.optString("url"), o.optString("group", "Outros"), o.optBoolean("embed")))
            }
            val fav = JSONArray(prefs.getString("favorites", "[]"))
            for (i in 0 until fav.length()) favorites.add(fav.getString(i))
        } catch (e: Exception) {
            // Dados salvos corrompidos: começa com a lista vazia.
        }
    }

    private fun showWelcome() {
        AlertDialog.Builder(this).setTitle("Bem-vindo ao DZZ Player")
            .setMessage("Adicione uma lista M3U/M3U8 ou cadastre um link de vídeo/embed para começar. Use os botões no topo com as setas do controle remoto.")
            .setPositiveButton("Entendi", null).show()
    }

    private fun toast(msg: String) = Toast.makeText(this, msg, Toast.LENGTH_SHORT).show()

    override fun onKeyDown(keyCode: Int, event: KeyEvent?): Boolean {
        if (keyCode == KeyEvent.KEYCODE_BACK && webView.visibility == View.VISIBLE) {
            if (webView.canGoBack()) webView.goBack()
            else { webView.stopLoading(); webView.visibility = View.GONE; playerView.visibility = View.VISIBLE }
            return true
        }
        return super.onKeyDown(keyCode, event)
    }

    override fun onStart() {
        super.onStart()
        webView.onResume()
    }

    // Ao apertar Home, o vídeo/áudio não deve continuar tocando em segundo plano.
    override fun onStop() {
        player?.pause()
        webView.onPause()
        super.onStop()
    }

    override fun onDestroy() {
        playerView.player = null
        player?.release(); webView.destroy()
        executor.shutdownNow()
        super.onDestroy()
    }
}
