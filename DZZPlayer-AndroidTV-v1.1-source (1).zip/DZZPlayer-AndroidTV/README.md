# DZZ Player — Android TV

Projeto inicial nativo para Android TV / Google TV.

## Recursos desta primeira base
- Interface horizontal em estilo TV, pensada para controle remoto/D-pad.
- Importação de listas M3U/M3U8 por URL.
- Leitura de nome e `group-title` de entradas `#EXTINF`.
- Reprodução de streams HTTP(S) compatíveis com Media3/ExoPlayer (incluindo HLS).
- Cadastro manual de links de vídeo e páginas embed.
- Favoritos e persistência local de canais.

## Limitações conhecidas
- Esta é uma primeira versão-base. O importador atual aceita listas M3U por URL; seletor de arquivos locais, logos/tvg-logo, EPG/XMLTV, atualização automática e gerenciamento de várias playlists ficam para a próxima iteração.
- Embeds são abertos em WebView. Alguns sites impedem incorporação, exigem DRM, login, cookies especiais ou APIs indisponíveis em Android TV; nesses casos não funcionarão.
- O app não fornece canais, listas ou conteúdo. Adicione somente fontes que você tenha autorização para acessar e reproduzir.
- Algumas transmissões exigem cabeçalhos HTTP, tokens ou formatos/DRM específicos ainda não implementados.

## Como gerar o APK
1. Instale o Android Studio em um computador.
2. Abra a pasta `DZZPlayer-AndroidTV` como projeto.
3. Aguarde a sincronização do Gradle e instale o Android SDK 35 quando solicitado.
4. Selecione **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
5. O APK de debug ficará em `app/build/outputs/apk/debug/app-debug.apk`.

## Instalação na TV
Ative as opções de desenvolvedor e a instalação de apps de fontes desconhecidas na Android TV. Transfira o APK por USB ou rede e instale-o usando um gerenciador de arquivos confiável.

## Requisitos
- Android Studio recente
- JDK 17
- Android SDK 35
- Gradle Wrapper pode ser criado pelo Android Studio na primeira abertura.

Package: `br.com.dzzplayer`
Version: `1.1`

## Mudanças da v1.1 (revisão do código)
- Corrigido erro de compilação: `catch (_: Exception)` não é aceito pelo Kotlin 2.0.
- Adicionados `media3-exoplayer-hls` e `-dash` (sem eles, listas .m3u8 não reproduziam).
- Destaque visual de foco em botões, categorias, canais e estrela (navegação por D-pad).
- Tamanhos da interface em dp em vez de pixels (antes ficava minúscula em TVs 4K).
- Seguir redirecionamentos http -> https ao importar listas.
- Aviso na tela quando um canal falha; pausa ao sair do app; foco preservado ao favoritar.
- Configuração Java/Kotlin 17 e `gradle-wrapper.properties` (Gradle 8.9).
- Workflow opcional em `.github/workflows/build-apk.yml` (GitHub Actions).
